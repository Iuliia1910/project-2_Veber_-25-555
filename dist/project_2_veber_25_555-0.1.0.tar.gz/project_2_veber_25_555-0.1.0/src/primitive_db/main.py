def main() -> None:
    print("DB project is running!")


if __name__ == "__main__":
    main()